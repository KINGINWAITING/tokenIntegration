"use client"

import { useState, useEffect } from "react"

export function useWallet() {
  const [address, setAddress] = useState<string | undefined>(undefined)
  const [isConnected, setIsConnected] = useState(false)

  useEffect(() => {
    // Simulate wallet connection
    // In a real implementation, this would connect to Thirdweb SDK
    const hasWallet = localStorage?.getItem("walletCreated") === "true"

    if (hasWallet) {
      // Mock address for demo purposes
      setAddress("0x71C7656EC7ab88b098defB751B7401B5f6d8976F")
      setIsConnected(true)
    }
  }, [])

  const connectWallet = () => {
    // Mock wallet connection
    setAddress("0x71C7656EC7ab88b098defB751B7401B5f6d8976F")
    setIsConnected(true)
    if (typeof window !== "undefined") {
      localStorage.setItem("walletCreated", "true")
    }
  }

  const disconnectWallet = () => {
    setAddress(undefined)
    setIsConnected(false)
    if (typeof window !== "undefined") {
      localStorage.removeItem("walletCreated")
    }
  }

  return {
    address,
    isConnected,
    connectWallet,
    disconnectWallet,
  }
}
