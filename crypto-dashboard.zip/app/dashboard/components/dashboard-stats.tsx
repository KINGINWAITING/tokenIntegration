"use client"

import type React from "react"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"
import { Coins, Award, Vote, TrendingUp } from "lucide-react"

interface DashboardStatsProps {
  tokenData: any
  nftData: any
  stakingData: any
  isLoading: boolean
}

export function DashboardStats({ tokenData, nftData, stakingData, isLoading }: DashboardStatsProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-8">
      <StatCard
        title="Token Balance"
        value={isLoading ? null : tokenData?.balance || "0"}
        description="Your MOONSET tokens"
        icon={<Coins className="h-5 w-5 text-purple-500" />}
        change={+12.5}
        isLoading={isLoading}
      />

      <StatCard
        title="NFT Collection"
        value={isLoading ? null : nftData?.count || "0"}
        description="Your access NFTs"
        icon={<Award className="h-5 w-5 text-pink-500" />}
        isLoading={isLoading}
      />

      <StatCard
        title="Staked Amount"
        value={isLoading ? null : stakingData?.stakedAmount || "0"}
        description="Currently staking"
        icon={<TrendingUp className="h-5 w-5 text-green-500" />}
        change={+5.2}
        isLoading={isLoading}
      />

      <StatCard
        title="Governance Power"
        value={isLoading ? null : tokenData?.votingPower || "0"}
        description="Your voting power"
        icon={<Vote className="h-5 w-5 text-blue-500" />}
        isLoading={isLoading}
      />
    </div>
  )
}

interface StatCardProps {
  title: string
  value: string | null
  description: string
  icon: React.ReactNode
  change?: number
  isLoading: boolean
}

function StatCard({ title, value, description, icon, change, isLoading }: StatCardProps) {
  return (
    <Card className="bg-white dark:bg-gray-900/50 backdrop-blur-sm border-gray-200 dark:border-gray-800 overflow-hidden relative">
      <div className="absolute inset-0 bg-gradient-to-br from-purple-100/30 to-pink-100/30 dark:from-purple-900/10 dark:to-pink-900/10 rounded-lg"></div>
      <CardHeader className="flex flex-row items-center justify-between pb-2 relative z-10">
        <CardTitle className="text-sm font-medium text-gray-600 dark:text-gray-300">{title}</CardTitle>
        <div className="p-2 bg-gray-100/80 dark:bg-gray-800/50 rounded-full">{icon}</div>
      </CardHeader>
      <CardContent className="relative z-10">
        {isLoading ? (
          <Skeleton className="h-8 w-24 bg-gray-200 dark:bg-gray-800" />
        ) : (
          <div className="text-2xl font-bold">{value}</div>
        )}
        <CardDescription className="text-gray-500 dark:text-gray-400 mt-1 flex items-center">
          {description}
          {change !== undefined && (
            <span className={`ml-2 text-xs font-medium ${change >= 0 ? "text-green-500" : "text-red-500"}`}>
              {change >= 0 ? "+" : ""}
              {change}%
            </span>
          )}
        </CardDescription>
      </CardContent>
    </Card>
  )
}
