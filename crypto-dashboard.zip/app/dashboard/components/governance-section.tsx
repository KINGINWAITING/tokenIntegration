"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Vote, CheckCircle, XCircle } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

interface GovernanceSectionProps {
  address?: string
  isConnected: boolean
  tokenData: any
  isLoading: boolean
  onConnect: () => void
}

export function GovernanceSection({ address, isConnected, tokenData, isLoading, onConnect }: GovernanceSectionProps) {
  const [activeTab, setActiveTab] = useState("active")
  const [newProposalTitle, setNewProposalTitle] = useState("")
  const [newProposalDescription, setNewProposalDescription] = useState("")
  const [isCreatingProposal, setIsCreatingProposal] = useState(false)

  const votingPower = tokenData?.votingPower || "0"

  const handleCreateProposal = () => {
    setIsCreatingProposal(true)
    // Simulate proposal creation
    setTimeout(() => {
      setIsCreatingProposal(false)
      setNewProposalTitle("")
      setNewProposalDescription("")
      // Handle success
    }, 2000)
  }

  if (!isConnected) {
    return (
      <Card className="bg-white dark:bg-gray-900/50 backdrop-blur-sm border-gray-200 dark:border-gray-800">
        <CardHeader>
          <CardTitle>Governance</CardTitle>
          <CardDescription>Connect your wallet to participate in governance</CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col items-center justify-center py-10">
          <div className="relative w-24 h-24 mb-6">
            <Vote className="w-24 h-24 text-gray-300 dark:text-gray-700" />
            <div className="absolute inset-0 bg-purple-500 rounded-full blur-xl opacity-20"></div>
          </div>
          <Button
            className="bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700"
            onClick={onConnect}
          >
            Connect Wallet
          </Button>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <Card className="lg:col-span-2 bg-white dark:bg-gray-900/50 backdrop-blur-sm border-gray-200 dark:border-gray-800 overflow-hidden relative">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-100/30 to-pink-100/30 dark:from-purple-900/10 dark:to-pink-900/10 rounded-lg"></div>
        <CardHeader className="relative z-10">
          <CardTitle>Governance Proposals</CardTitle>
          <CardDescription>Vote on proposals and shape the future of MOONSET</CardDescription>
        </CardHeader>
        <CardContent className="relative z-10">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid grid-cols-3 mb-6">
              <TabsTrigger value="active">Active</TabsTrigger>
              <TabsTrigger value="passed">Passed</TabsTrigger>
              <TabsTrigger value="rejected">Rejected</TabsTrigger>
            </TabsList>

            <TabsContent value="active">
              <div className="space-y-4">
                <ProposalItem
                  id="PROP-001"
                  title="Increase Staking Rewards"
                  description="Proposal to increase the NFT rewards for staking MOONSET tokens"
                  status="active"
                  votesFor={65}
                  votesAgainst={35}
                  endDate="Aug 15, 2023"
                  author="0x1234...5678"
                  votingPower={votingPower}
                />
                <ProposalItem
                  id="PROP-002"
                  title="Add New Research Categories"
                  description="Add new research categories for blockchain security and privacy"
                  status="active"
                  votesFor={78}
                  votesAgainst={22}
                  endDate="Aug 20, 2023"
                  author="0x8765...4321"
                  votingPower={votingPower}
                />
              </div>
            </TabsContent>

            <TabsContent value="passed">
              <div className="space-y-4">
                <ProposalItem
                  id="PROP-000"
                  title="Launch MOONSET Token"
                  description="Proposal to launch the MOONSET token on Ethereum mainnet"
                  status="passed"
                  votesFor={92}
                  votesAgainst={8}
                  endDate="July 10, 2023"
                  author="0x1234...5678"
                  votingPower={votingPower}
                />
              </div>
            </TabsContent>

            <TabsContent value="rejected">
              <div className="text-center py-10">
                <XCircle className="h-12 w-12 mx-auto text-gray-300 dark:text-gray-700 mb-4" />
                <p className="text-gray-500 dark:text-gray-400">No rejected proposals</p>
                <p className="text-sm text-gray-500 dark:text-gray-500 mt-1">Rejected proposals will appear here</p>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      <div className="space-y-6">
        <Card className="bg-white dark:bg-gray-900/50 backdrop-blur-sm border-gray-200 dark:border-gray-800 overflow-hidden relative">
          <div className="absolute inset-0 bg-gradient-to-br from-purple-100/30 to-pink-100/30 dark:from-purple-900/10 dark:to-pink-900/10 rounded-lg"></div>
          <CardHeader className="relative z-10">
            <CardTitle>Your Voting Power</CardTitle>
            <CardDescription>Based on your token holdings and staked amount</CardDescription>
          </CardHeader>
          <CardContent className="relative z-10">
            <div className="flex items-center justify-between p-4 bg-gray-100/80 dark:bg-gray-800/50 rounded-lg mb-4">
              <div className="flex items-center">
                <div className="p-3 bg-gray-200 dark:bg-gray-800 rounded-full mr-4">
                  <Vote className="h-5 w-5 text-purple-600 dark:text-purple-500" />
                </div>
                <div>
                  <p className="font-medium">Voting Power</p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">1 token = 1 vote</p>
                </div>
              </div>
              <div className="text-right">
                <p className="font-bold text-2xl">{votingPower}</p>
                <p className="text-sm text-gray-500 dark:text-gray-400">votes</p>
              </div>
            </div>

            <Button
              className="w-full bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700"
              onClick={() => {
                if (typeof document !== "undefined") {
                  document.getElementById("create-proposal")?.scrollIntoView({ behavior: "smooth" })
                }
              }}
            >
              Create Proposal
            </Button>
          </CardContent>
        </Card>

        <Card
          id="create-proposal"
          className="bg-white dark:bg-gray-900/50 backdrop-blur-sm border-gray-200 dark:border-gray-800 overflow-hidden relative"
        >
          <div className="absolute inset-0 bg-gradient-to-br from-purple-100/30 to-pink-100/30 dark:from-purple-900/10 dark:to-pink-900/10 rounded-lg"></div>
          <CardHeader className="relative z-10">
            <CardTitle>Create Proposal</CardTitle>
            <CardDescription>Submit a new governance proposal</CardDescription>
          </CardHeader>
          <CardContent className="relative z-10">
            <div className="space-y-4">
              <div className="space-y-2">
                <label htmlFor="proposal-title" className="text-sm font-medium">
                  Proposal Title
                </label>
                <Input
                  id="proposal-title"
                  value={newProposalTitle}
                  onChange={(e) => setNewProposalTitle(e.target.value)}
                  placeholder="Enter proposal title"
                />
              </div>

              <div className="space-y-2">
                <label htmlFor="proposal-description" className="text-sm font-medium">
                  Proposal Description
                </label>
                <Textarea
                  id="proposal-description"
                  value={newProposalDescription}
                  onChange={(e) => setNewProposalDescription(e.target.value)}
                  placeholder="Describe your proposal in detail"
                  rows={5}
                />
              </div>
            </div>
          </CardContent>
          <CardFooter className="relative z-10">
            <Button
              className="w-full bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700"
              onClick={handleCreateProposal}
              disabled={
                isCreatingProposal ||
                !newProposalTitle ||
                !newProposalDescription ||
                Number.parseFloat(votingPower) < 100
              }
            >
              {isCreatingProposal ? "Creating..." : "Submit Proposal"}
            </Button>
          </CardFooter>
          {Number.parseFloat(votingPower) < 100 && (
            <div className="px-6 pb-4 relative z-10">
              <p className="text-xs text-amber-500 dark:text-amber-400">
                You need at least 100 voting power to create a proposal. Stake more tokens to increase your voting
                power.
              </p>
            </div>
          )}
        </Card>
      </div>
    </div>
  )
}

interface ProposalItemProps {
  id: string
  title: string
  description: string
  status: "active" | "passed" | "rejected"
  votesFor: number
  votesAgainst: number
  endDate: string
  author: string
  votingPower: string
}

function ProposalItem({
  id,
  title,
  description,
  status,
  votesFor,
  votesAgainst,
  endDate,
  author,
  votingPower,
}: ProposalItemProps) {
  const [vote, setVote] = useState<"for" | "against" | null>(null)
  const [isVoting, setIsVoting] = useState(false)

  const handleVote = (voteType: "for" | "against") => {
    setIsVoting(true)
    // Simulate voting
    setTimeout(() => {
      setVote(voteType)
      setIsVoting(false)
    }, 1000)
  }

  return (
    <Card className="bg-gray-100/80 dark:bg-gray-800/50 border-gray-200 dark:border-gray-700">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div>
            <div className="flex items-center">
              <CardTitle className="text-base">{title}</CardTitle>
              <Badge
                variant="outline"
                className={`ml-2 ${
                  status === "active"
                    ? "border-blue-300 dark:border-blue-600 text-blue-600 dark:text-blue-400 bg-blue-100/50 dark:bg-blue-900/20"
                    : status === "passed"
                      ? "border-green-300 dark:border-green-600 text-green-600 dark:text-green-400 bg-green-100/50 dark:bg-green-900/20"
                      : "border-red-300 dark:border-red-600 text-red-600 dark:text-red-400 bg-red-100/50 dark:bg-red-900/20"
                }`}
              >
                {status.charAt(0).toUpperCase() + status.slice(1)}
              </Badge>
            </div>
            <CardDescription className="mt-1">{description}</CardDescription>
          </div>
          <div className="text-xs text-gray-500">ID: {id}</div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div>
            <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400 mb-1">
              <span>For: {votesFor}%</span>
              <span>Against: {votesAgainst}%</span>
            </div>
            <div className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
              <div className="h-full bg-green-500" style={{ width: `${votesFor}%` }}></div>
            </div>
          </div>

          <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400">
            <div className="flex items-center">
              <Avatar className="h-5 w-5 mr-1">
                <AvatarImage src={`https://effigy.im/a/${author}.svg`} />
                <AvatarFallback>A</AvatarFallback>
              </Avatar>
              <span>
                Created by {author.slice(0, 6)}...{author.slice(-4)}
              </span>
            </div>
            <span>Ends on {endDate}</span>
          </div>

          {status === "active" && (
            <div className="flex space-x-2 pt-2">
              <Button
                variant={vote === "for" ? "default" : "outline"}
                className={`flex-1 ${vote === "for" ? "bg-green-600 hover:bg-green-700" : "border-gray-300 dark:border-gray-700"}`}
                onClick={() => handleVote("for")}
                disabled={isVoting || Number.parseFloat(votingPower) <= 0}
              >
                <CheckCircle className="h-4 w-4 mr-2" />
                For
              </Button>
              <Button
                variant={vote === "against" ? "default" : "outline"}
                className={`flex-1 ${vote === "against" ? "bg-red-600 hover:bg-red-700" : "border-gray-300 dark:border-gray-700"}`}
                onClick={() => handleVote("against")}
                disabled={isVoting || Number.parseFloat(votingPower) <= 0}
              >
                <XCircle className="h-4 w-4 mr-2" />
                Against
              </Button>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
