"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { CreditCard, Coins, DollarSign, Info } from "lucide-react"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

interface OnrampSectionProps {
  address?: string
  isConnected: boolean
  tokenData: any
  isLoading: boolean
  onConnect: () => void
}

export function OnrampSection({ address, isConnected, tokenData, isLoading, onConnect }: OnrampSectionProps) {
  const [amount, setAmount] = useState("100")
  const [paymentMethod, setPaymentMethod] = useState("card")
  const [currency, setCurrency] = useState("usd")
  const [isProcessing, setIsProcessing] = useState(false)

  const exchangeRate = 10 // 1 USD = 10 MOONSET tokens
  const estimatedTokens = Number.parseFloat(amount) * exchangeRate
  const fees = Number.parseFloat(amount) * 0.025 // 2.5% fee

  const handlePurchase = () => {
    setIsProcessing(true)
    // Simulate MoonPay integration
    setTimeout(() => {
      setIsProcessing(false)
      // Handle success
    }, 2000)
  }

  if (!isConnected) {
    return (
      <Card className="bg-white dark:bg-gray-900/50 backdrop-blur-sm border-gray-200 dark:border-gray-800">
        <CardHeader>
          <CardTitle>Buy MOONSET Tokens</CardTitle>
          <CardDescription>Connect your wallet to purchase tokens</CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col items-center justify-center py-10">
          <div className="relative w-24 h-24 mb-6">
            <Coins className="w-24 h-24 text-gray-300 dark:text-gray-700" />
            <div className="absolute inset-0 bg-purple-500 rounded-full blur-xl opacity-20"></div>
          </div>
          <Button
            className="bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700"
            onClick={onConnect}
          >
            Connect Wallet
          </Button>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <Card className="lg:col-span-2 bg-white dark:bg-gray-900/50 backdrop-blur-sm border-gray-200 dark:border-gray-800 overflow-hidden relative">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-100/30 to-pink-100/30 dark:from-purple-900/10 dark:to-pink-900/10 rounded-lg"></div>
        <CardHeader className="relative z-10">
          <CardTitle>Buy MOONSET Tokens</CardTitle>
          <CardDescription>Purchase tokens directly with fiat currency via MoonPay</CardDescription>
        </CardHeader>
        <CardContent className="relative z-10">
          <Tabs defaultValue="buy" className="w-full">
            <TabsList className="grid grid-cols-2 mb-6">
              <TabsTrigger value="buy">Buy</TabsTrigger>
              <TabsTrigger value="history">History</TabsTrigger>
            </TabsList>

            <TabsContent value="buy">
              <div className="space-y-6">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <Label htmlFor="amount">Amount</Label>
                    <Select value={currency} onValueChange={setCurrency}>
                      <SelectTrigger className="w-24">
                        <SelectValue placeholder="Currency" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="usd">USD</SelectItem>
                        <SelectItem value="eur">EUR</SelectItem>
                        <SelectItem value="gbp">GBP</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-3 h-4 w-4 text-gray-500" />
                    <Input
                      id="amount"
                      type="number"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      className="pl-10"
                      placeholder="Enter amount"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Payment Method</Label>
                  <div className="grid grid-cols-2 gap-4">
                    <Button
                      variant={paymentMethod === "card" ? "default" : "outline"}
                      className={`flex items-center justify-center ${paymentMethod === "card" ? "bg-purple-600 hover:bg-purple-700" : "border-gray-300 dark:border-gray-700"}`}
                      onClick={() => setPaymentMethod("card")}
                    >
                      <CreditCard className="h-4 w-4 mr-2" />
                      Credit Card
                    </Button>
                    <Button
                      variant={paymentMethod === "bank" ? "default" : "outline"}
                      className={`flex items-center justify-center ${paymentMethod === "bank" ? "bg-purple-600 hover:bg-purple-700" : "border-gray-300 dark:border-gray-700"}`}
                      onClick={() => setPaymentMethod("bank")}
                    >
                      <DollarSign className="h-4 w-4 mr-2" />
                      Bank Transfer
                    </Button>
                  </div>
                </div>

                <div className="space-y-4 p-4 bg-gray-100/80 dark:bg-gray-800/50 rounded-lg">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500 dark:text-gray-400">Exchange Rate</span>
                    <span>
                      1 {currency.toUpperCase()} = {exchangeRate} MOONSET
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500 dark:text-gray-400">Estimated Tokens</span>
                    <span className="font-medium">{estimatedTokens.toFixed(2)} MOONSET</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500 dark:text-gray-400 flex items-center">
                      Fees
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger>
                            <Info className="h-3 w-3 ml-1 text-gray-500" />
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>MoonPay processing fee (2.5%)</p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </span>
                    <span>${fees.toFixed(2)}</span>
                  </div>
                  <div className="border-t border-gray-300 dark:border-gray-700 my-2"></div>
                  <div className="flex justify-between">
                    <span className="font-medium">Total Cost</span>
                    <span className="font-bold">${(Number.parseFloat(amount) + fees).toFixed(2)}</span>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="history">
              <div className="text-center py-10">
                <p className="text-gray-500 dark:text-gray-400">No purchase history found</p>
                <p className="text-sm text-gray-500 dark:text-gray-500 mt-1">Your purchase history will appear here</p>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
        <CardFooter className="relative z-10">
          <Button
            className="w-full bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700"
            onClick={handlePurchase}
            disabled={isProcessing || Number.parseFloat(amount) <= 0}
          >
            {isProcessing ? "Processing..." : "Buy Tokens"}
          </Button>
        </CardFooter>
      </Card>

      <Card className="bg-white dark:bg-gray-900/50 backdrop-blur-sm border-gray-200 dark:border-gray-800 overflow-hidden relative">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-100/30 to-pink-100/30 dark:from-purple-900/10 dark:to-pink-900/10 rounded-lg"></div>
        <CardHeader className="relative z-10">
          <CardTitle>How It Works</CardTitle>
          <CardDescription>Learn about the token purchase process</CardDescription>
        </CardHeader>
        <CardContent className="relative z-10">
          <div className="space-y-6">
            <div className="flex items-start">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-purple-100 dark:bg-purple-900/50 flex items-center justify-center mr-4">
                <span className="font-bold text-purple-600 dark:text-purple-400">1</span>
              </div>
              <div>
                <h4 className="font-medium">Enter Amount</h4>
                <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                  Choose how much you want to spend in your preferred currency
                </p>
              </div>
            </div>

            <div className="flex items-start">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-purple-100 dark:bg-purple-900/50 flex items-center justify-center mr-4">
                <span className="font-bold text-purple-600 dark:text-purple-400">2</span>
              </div>
              <div>
                <h4 className="font-medium">Select Payment Method</h4>
                <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                  Choose between credit card or bank transfer via MoonPay
                </p>
              </div>
            </div>

            <div className="flex items-start">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-purple-100 dark:bg-purple-900/50 flex items-center justify-center mr-4">
                <span className="font-bold text-purple-600 dark:text-purple-400">3</span>
              </div>
              <div>
                <h4 className="font-medium">Complete Purchase</h4>
                <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                  Follow the payment steps and confirm your transaction
                </p>
              </div>
            </div>

            <div className="flex items-start">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-purple-100 dark:bg-purple-900/50 flex items-center justify-center mr-4">
                <span className="font-bold text-purple-600 dark:text-purple-400">4</span>
              </div>
              <div>
                <h4 className="font-medium">Receive Tokens</h4>
                <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                  MOONSET tokens will be sent directly to your embedded wallet
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
