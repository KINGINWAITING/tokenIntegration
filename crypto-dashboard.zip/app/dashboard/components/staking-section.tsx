"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { TrendingUp, Clock, Award, AlertCircle } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Canvas } from "@react-three/fiber"
import { Environment, OrbitControls } from "@react-three/drei"
import { TokenModel } from "./token-model"

interface StakingSectionProps {
  address?: string
  isConnected: boolean
  tokenData: any
  stakingData: any
  isLoading: boolean
  onConnect: () => void
}

export function StakingSection({
  address,
  isConnected,
  tokenData,
  stakingData,
  isLoading,
  onConnect,
}: StakingSectionProps) {
  const [stakeAmount, setStakeAmount] = useState("0")
  const [stakePercentage, setStakePercentage] = useState(0)
  const [isStaking, setIsStaking] = useState(false)

  const maxStakeAmount = tokenData?.balance || "0"

  const handleSliderChange = (value: number[]) => {
    const percentage = value[0]
    setStakePercentage(percentage)
    const amount = ((Number.parseFloat(maxStakeAmount) * percentage) / 100).toFixed(2)
    setStakeAmount(amount)
  }

  const handleInputChange = (value: string) => {
    setStakeAmount(value)
    const percentage = Math.min(100, (Number.parseFloat(value) / Number.parseFloat(maxStakeAmount)) * 100 || 0)
    setStakePercentage(percentage)
  }

  const handleStake = () => {
    setIsStaking(true)
    // Simulate staking
    setTimeout(() => {
      setIsStaking(false)
      // Handle success
    }, 2000)
  }

  if (!isConnected) {
    return (
      <Card className="bg-white dark:bg-gray-900/50 backdrop-blur-sm border-gray-200 dark:border-gray-800">
        <CardHeader>
          <CardTitle>Stake Your Tokens</CardTitle>
          <CardDescription>Connect your wallet to stake tokens and earn rewards</CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col items-center justify-center py-10">
          <div className="relative w-24 h-24 mb-6">
            <TrendingUp className="w-24 h-24 text-gray-300 dark:text-gray-700" />
            <div className="absolute inset-0 bg-purple-500 rounded-full blur-xl opacity-20"></div>
          </div>
          <Button
            className="bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700"
            onClick={onConnect}
          >
            Connect Wallet
          </Button>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <Card className="lg:col-span-2 bg-white dark:bg-gray-900/50 backdrop-blur-sm border-gray-200 dark:border-gray-800 overflow-hidden relative">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-100/30 to-pink-100/30 dark:from-purple-900/10 dark:to-pink-900/10 rounded-lg"></div>
        <CardHeader className="relative z-10">
          <CardTitle>Stake Your Tokens</CardTitle>
          <CardDescription>Stake MOONSET tokens to earn NFT rewards and governance rights</CardDescription>
        </CardHeader>
        <CardContent className="relative z-10">
          <Tabs defaultValue="stake" className="w-full">
            <TabsList className="grid grid-cols-2 mb-6">
              <TabsTrigger value="stake">Stake</TabsTrigger>
              <TabsTrigger value="unstake">Unstake</TabsTrigger>
            </TabsList>

            <TabsContent value="stake">
              <div className="space-y-6">
                <Alert className="bg-purple-100/50 dark:bg-purple-900/20 border-purple-200 dark:border-purple-800">
                  <AlertCircle className="h-4 w-4 text-purple-600 dark:text-purple-400" />
                  <AlertTitle>Staking Information</AlertTitle>
                  <AlertDescription>
                    Stake your MOONSET tokens to earn NFT rewards. Minimum staking period is 30 days.
                  </AlertDescription>
                </Alert>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <Label htmlFor="stake-amount">Stake Amount</Label>
                    <span className="text-sm text-gray-500 dark:text-gray-400">Balance: {maxStakeAmount} MOONSET</span>
                  </div>
                  <div className="relative">
                    <Input
                      id="stake-amount"
                      type="number"
                      value={stakeAmount}
                      onChange={(e) => handleInputChange(e.target.value)}
                      className="pr-20"
                      placeholder="Enter amount to stake"
                    />
                    <Button
                      variant="ghost"
                      size="sm"
                      className="absolute right-0 top-0 h-full px-3 text-xs text-purple-600 dark:text-purple-400 hover:text-purple-500 dark:hover:text-purple-300"
                      onClick={() => handleInputChange(maxStakeAmount)}
                    >
                      MAX
                    </Button>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex justify-between text-sm">
                    <span>0%</span>
                    <span>50%</span>
                    <span>100%</span>
                  </div>
                  <Slider
                    value={[stakePercentage]}
                    onValueChange={handleSliderChange}
                    max={100}
                    step={1}
                    className="[&>span:first-child]:bg-purple-600"
                  />
                </div>

                <div className="space-y-4 p-4 bg-gray-100/80 dark:bg-gray-800/50 rounded-lg">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500 dark:text-gray-400">Staking Period</span>
                    <span>30 days (minimum)</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500 dark:text-gray-400">Reward Type</span>
                    <span>Access NFT</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500 dark:text-gray-400">Governance Power</span>
                    <span>+{Number.parseFloat(stakeAmount) > 0 ? Number.parseFloat(stakeAmount) : 0} votes</span>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="unstake">
              {stakingData?.stakedAmount && Number.parseFloat(stakingData.stakedAmount) > 0 ? (
                <div className="space-y-6">
                  <div className="p-4 bg-gray-100/80 dark:bg-gray-800/50 rounded-lg">
                    <div className="flex justify-between mb-2">
                      <span className="text-gray-500 dark:text-gray-400">Currently Staked</span>
                      <span className="font-medium">{stakingData.stakedAmount} MOONSET</span>
                    </div>
                    <div className="flex justify-between mb-2">
                      <span className="text-gray-500 dark:text-gray-400">Staking Period</span>
                      <div className="flex items-center">
                        <Clock className="h-4 w-4 mr-1 text-gray-500" />
                        <span>{stakingData.remainingDays || 30} days remaining</span>
                      </div>
                    </div>
                    <div className="mt-4">
                      <Label className="text-sm text-gray-500 dark:text-gray-400 mb-2 block">Staking Progress</Label>
                      <Progress
                        value={stakingData.progressPercentage || 0}
                        className="h-2 bg-gray-200 dark:bg-gray-700"
                      />
                      <div className="flex justify-between mt-1 text-xs text-gray-500">
                        <span>Start Date: {stakingData.startDate || "N/A"}</span>
                        <span>End Date: {stakingData.endDate || "N/A"}</span>
                      </div>
                    </div>
                  </div>

                  <Alert
                    variant="destructive"
                    className="bg-red-100/50 dark:bg-red-900/20 border-red-200 dark:border-red-800"
                  >
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>Early Unstaking Warning</AlertTitle>
                    <AlertDescription>
                      Unstaking before the minimum period will result in forfeiting any pending rewards.
                    </AlertDescription>
                  </Alert>

                  <Button
                    variant="outline"
                    className="w-full border-red-300 dark:border-red-700 text-red-600 dark:text-red-400 hover:bg-red-100/50 dark:hover:bg-red-900/20 hover:text-red-700 dark:hover:text-red-300"
                  >
                    Unstake Tokens
                  </Button>
                </div>
              ) : (
                <div className="text-center py-10">
                  <TrendingUp className="h-12 w-12 mx-auto text-gray-300 dark:text-gray-700 mb-4" />
                  <p className="text-gray-500 dark:text-gray-400">No staked tokens found</p>
                  <p className="text-sm text-gray-500 dark:text-gray-500 mt-1">Stake your tokens to earn rewards</p>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
        <CardFooter className="relative z-10">
          <Button
            className="w-full bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700"
            onClick={handleStake}
            disabled={isStaking || Number.parseFloat(stakeAmount) <= 0}
          >
            {isStaking ? "Processing..." : "Stake Tokens"}
          </Button>
        </CardFooter>
      </Card>

      <Card className="bg-white dark:bg-gray-900/50 backdrop-blur-sm border-gray-200 dark:border-gray-800 overflow-hidden relative">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-100/30 to-pink-100/30 dark:from-purple-900/10 dark:to-pink-900/10 rounded-lg"></div>
        <CardHeader className="relative z-10">
          <CardTitle>NFT Rewards</CardTitle>
          <CardDescription>Earn exclusive NFTs by staking your tokens</CardDescription>
        </CardHeader>
        <CardContent className="relative z-10">
          <div className="aspect-square rounded-lg bg-gray-100 dark:bg-gray-800/50 mb-6 overflow-hidden">
            <div className="w-full h-full">
              <Canvas>
                <ambientLight intensity={0.5} />
                <spotLight position={[10, 10, 10]} angle={0.15} penumbra={1} />
                <TokenModel position={[0, 0, 0]} scale={5} />
                <OrbitControls enableZoom={false} autoRotate />
                <Environment preset="sunset" />
              </Canvas>
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex items-start">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-purple-100 dark:bg-purple-900/50 flex items-center justify-center mr-4">
                <Award className="h-4 w-4 text-purple-600 dark:text-purple-400" />
              </div>
              <div>
                <h4 className="font-medium">Access NFTs</h4>
                <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                  Stake 100+ MOONSET tokens for 30 days to earn a Basic Access NFT
                </p>
              </div>
            </div>

            <div className="flex items-start">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-purple-100 dark:bg-purple-900/50 flex items-center justify-center mr-4">
                <Award className="h-4 w-4 text-purple-600 dark:text-purple-400" />
              </div>
              <div>
                <h4 className="font-medium">Premium Access</h4>
                <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                  Stake 500+ MOONSET tokens for 60 days to earn a Premium Access NFT
                </p>
              </div>
            </div>

            <div className="flex items-start">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-purple-100 dark:bg-purple-900/50 flex items-center justify-center mr-4">
                <Award className="h-4 w-4 text-purple-600 dark:text-purple-400" />
              </div>
              <div>
                <h4 className="font-medium">Exclusive Access</h4>
                <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                  Stake 1000+ MOONSET tokens for 90 days to earn an Exclusive Access NFT
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
