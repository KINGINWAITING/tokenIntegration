"use client"

import { Button } from "@/components/ui/button"
import { Wallet, Moon, Sun, Menu } from "lucide-react"
import { useState } from "react"
import { useTheme } from "next-themes"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { useWallet } from "@/hooks/use-wallet"

interface DashboardHeaderProps {
  address?: string
  isConnected: boolean
  onConnect: () => void
}

export function DashboardHeader({ address, isConnected, onConnect }: DashboardHeaderProps) {
  const { theme, setTheme } = useTheme()
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const { disconnectWallet } = useWallet()

  const shortenAddress = (addr?: string) => {
    if (!addr) return ""
    return `${addr.slice(0, 6)}...${addr.slice(-4)}`
  }

  return (
    <header className="flex items-center justify-between py-6">
      <div className="flex items-center">
        <div className="mr-2 relative w-10 h-10">
          <Moon className="w-10 h-10 text-purple-500" />
          <div className="absolute inset-0 bg-purple-500 rounded-full blur-xl opacity-30 animate-pulse"></div>
        </div>
        <h1 className="text-2xl font-bold">MOONSET</h1>
      </div>

      <div className="hidden md:flex items-center space-x-4">
        <Button
          variant="outline"
          size="sm"
          className="border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300"
          onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
        >
          {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
        </Button>

        {isConnected ? (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="outline"
                className="border-purple-200 dark:border-purple-700 bg-white/50 dark:bg-gray-900/50 backdrop-blur-sm"
              >
                <Avatar className="h-6 w-6 mr-2">
                  <AvatarImage src={`https://effigy.im/a/${address}.svg`} />
                  <AvatarFallback>
                    <Wallet className="h-4 w-4" />
                  </AvatarFallback>
                </Avatar>
                {shortenAddress(address)}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-800">
              <DropdownMenuLabel>My Account</DropdownMenuLabel>
              <DropdownMenuSeparator className="bg-gray-200 dark:bg-gray-800" />
              <DropdownMenuItem className="cursor-pointer">Profile</DropdownMenuItem>
              <DropdownMenuItem className="cursor-pointer">Settings</DropdownMenuItem>
              <DropdownMenuItem className="cursor-pointer" onClick={disconnectWallet}>
                Disconnect
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        ) : (
          <Button
            className="bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700"
            onClick={onConnect}
          >
            <Wallet className="h-4 w-4 mr-2" />
            Connect Wallet
          </Button>
        )}
      </div>

      <div className="md:hidden">
        <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon">
              <Menu className="h-6 w-6" />
            </Button>
          </SheetTrigger>
          <SheetContent side="right" className="bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-800">
            <div className="flex flex-col space-y-4 mt-8">
              {isConnected ? (
                <div className="flex items-center p-2 bg-gray-100 dark:bg-gray-800 rounded-lg">
                  <Avatar className="h-8 w-8 mr-2">
                    <AvatarImage src={`https://effigy.im/a/${address}.svg`} />
                    <AvatarFallback>
                      <Wallet className="h-4 w-4" />
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex flex-col">
                    <span className="text-sm font-medium">Connected</span>
                    <span className="text-xs text-gray-500 dark:text-gray-400">{shortenAddress(address)}</span>
                  </div>
                </div>
              ) : (
                <Button
                  className="bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700"
                  onClick={onConnect}
                >
                  <Wallet className="h-4 w-4 mr-2" />
                  Connect Wallet
                </Button>
              )}

              <Button
                variant="outline"
                size="sm"
                className="border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 justify-start"
                onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
              >
                {theme === "dark" ? <Sun className="h-4 w-4 mr-2" /> : <Moon className="h-4 w-4 mr-2" />}
                {theme === "dark" ? "Light Mode" : "Dark Mode"}
              </Button>
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </header>
  )
}
