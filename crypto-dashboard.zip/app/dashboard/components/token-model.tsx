"use client"

import { useRef } from "react"
import { useFrame } from "@react-three/fiber"
import { MeshDistortMaterial } from "@react-three/drei"
import type * as THREE from "three"

interface TokenModelProps {
  position: [number, number, number]
  scale: number
}

export function TokenModel({ position, scale }: TokenModelProps) {
  const meshRef = useRef<THREE.Mesh>(null)

  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.x = Math.sin(state.clock.getElapsedTime() * 0.3) * 0.2
      meshRef.current.rotation.y += 0.01
    }
  })

  return (
    <mesh ref={meshRef} position={position} scale={scale}>
      <torusGeometry args={[1, 0.4, 16, 32]} />
      <MeshDistortMaterial color="#9333ea" attach="material" distort={0.3} speed={2} roughness={0.4} metalness={0.8} />
    </mesh>
  )
}
