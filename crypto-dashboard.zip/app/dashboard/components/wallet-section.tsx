"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { Copy, ExternalLink, Wallet, Coins, Award } from "lucide-react"
import { useState } from "react"
import { useToast } from "@/hooks/use-toast"

interface WalletSectionProps {
  address?: string
  isConnected: boolean
  tokenData: any
  nftData: any
  isLoading: boolean
  onConnect: () => void
}

export function WalletSection({ address, isConnected, tokenData, nftData, isLoading, onConnect }: WalletSectionProps) {
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState("tokens")

  const copyAddress = () => {
    if (address) {
      navigator.clipboard.writeText(address)
      toast({
        title: "Address copied",
        description: "Wallet address copied to clipboard",
      })
    }
  }

  const shortenAddress = (addr?: string) => {
    if (!addr) return ""
    return `${addr.slice(0, 10)}...${addr.slice(-8)}`
  }

  if (!isConnected) {
    return (
      <Card className="bg-white dark:bg-gray-900/50 backdrop-blur-sm border-gray-200 dark:border-gray-800">
        <CardHeader>
          <CardTitle>Connect Your Wallet</CardTitle>
          <CardDescription>Connect your wallet to view your assets and manage your tokens</CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col items-center justify-center py-10">
          <div className="relative w-24 h-24 mb-6">
            <Wallet className="w-24 h-24 text-gray-300 dark:text-gray-700" />
            <div className="absolute inset-0 bg-purple-500 rounded-full blur-xl opacity-20"></div>
          </div>
          <Button
            className="bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700"
            onClick={onConnect}
          >
            Connect Wallet
          </Button>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      <Card className="bg-white dark:bg-gray-900/50 backdrop-blur-sm border-gray-200 dark:border-gray-800 overflow-hidden relative">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-100/30 to-pink-100/30 dark:from-purple-900/10 dark:to-pink-900/10 rounded-lg"></div>
        <CardHeader className="relative z-10">
          <CardTitle>Your Wallet</CardTitle>
          <CardDescription>Manage your embedded wallet and assets</CardDescription>
        </CardHeader>
        <CardContent className="relative z-10">
          <div className="flex flex-col md:flex-row md:items-center justify-between p-4 bg-gray-100/80 dark:bg-gray-800/50 rounded-lg mb-6">
            <div className="flex items-center mb-4 md:mb-0">
              <div className="p-3 bg-gray-200 dark:bg-gray-800 rounded-full mr-4">
                <Wallet className="h-6 w-6 text-purple-500" />
              </div>
              <div>
                <p className="text-sm text-gray-500 dark:text-gray-400">Wallet Address</p>
                <p className="font-mono">{shortenAddress(address)}</p>
              </div>
            </div>
            <div className="flex space-x-2">
              <Button variant="outline" size="sm" onClick={copyAddress}>
                <Copy className="h-4 w-4 mr-2" />
                Copy
              </Button>
              <Button variant="outline" size="sm">
                <ExternalLink className="h-4 w-4 mr-2" />
                Explorer
              </Button>
            </div>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid grid-cols-2 mb-6">
              <TabsTrigger value="tokens">Tokens</TabsTrigger>
              <TabsTrigger value="nfts">NFTs</TabsTrigger>
            </TabsList>

            <TabsContent value="tokens">
              {isLoading ? (
                <div className="space-y-4">
                  <Skeleton className="h-20 w-full bg-gray-200 dark:bg-gray-800" />
                  <Skeleton className="h-20 w-full bg-gray-200 dark:bg-gray-800" />
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-gray-100/80 dark:bg-gray-800/50 rounded-lg">
                    <div className="flex items-center">
                      <div className="relative w-10 h-10 mr-4">
                        <Coins className="w-10 h-10 text-purple-500" />
                        <div className="absolute inset-0 bg-purple-500 rounded-full blur-lg opacity-30"></div>
                      </div>
                      <div>
                        <p className="font-medium">MOONSET Token</p>
                        <p className="text-sm text-gray-500 dark:text-gray-400">ERC-20</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-xl">{tokenData?.balance || "0"}</p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">${tokenData?.usdValue || "0.00"}</p>
                    </div>
                  </div>
                </div>
              )}
            </TabsContent>

            <TabsContent value="nfts">
              {isLoading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Skeleton className="h-40 w-full bg-gray-200 dark:bg-gray-800" />
                  <Skeleton className="h-40 w-full bg-gray-200 dark:bg-gray-800" />
                </div>
              ) : nftData?.items?.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {nftData.items.map((nft: any, index: number) => (
                    <div key={index} className="p-4 bg-gray-100/80 dark:bg-gray-800/50 rounded-lg">
                      <div className="aspect-square rounded-lg bg-gray-200 dark:bg-gray-800 mb-3 overflow-hidden">
                        {nft.image ? (
                          <img
                            src={nft.image || "/placeholder.svg"}
                            alt={nft.name}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center">
                            <Award className="h-12 w-12 text-gray-300 dark:text-gray-700" />
                          </div>
                        )}
                      </div>
                      <p className="font-medium">{nft.name || `MOONSET NFT #${nft.id}`}</p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        Access Level: {nft.accessLevel || "Standard"}
                      </p>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-10">
                  <Award className="h-12 w-12 mx-auto text-gray-300 dark:text-gray-700 mb-4" />
                  <p className="text-gray-500 dark:text-gray-400">No NFTs found in your wallet</p>
                  <p className="text-sm text-gray-500 dark:text-gray-500 mt-1">Stake your tokens to earn NFTs</p>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}
