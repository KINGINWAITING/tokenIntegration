"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Lock, FileText, ExternalLink } from "lucide-react"
import { useState } from "react"

interface ResearchAccessSectionProps {
  address?: string
  isConnected: boolean
  nftData: any
  isLoading: boolean
  onConnect: () => void
}

export function ResearchAccessSection({
  address,
  isConnected,
  nftData,
  isLoading,
  onConnect,
}: ResearchAccessSectionProps) {
  const [activeTab, setActiveTab] = useState("available")

  // Check if user has access based on NFTs
  const hasBasicAccess = nftData?.items?.some(
    (nft: any) => nft.accessLevel === "Basic" || nft.accessLevel === "Premium" || nft.accessLevel === "Exclusive",
  )
  const hasPremiumAccess = nftData?.items?.some(
    (nft: any) => nft.accessLevel === "Premium" || nft.accessLevel === "Exclusive",
  )
  const hasExclusiveAccess = nftData?.items?.some((nft: any) => nft.accessLevel === "Exclusive")

  if (!isConnected) {
    return (
      <Card className="bg-white dark:bg-gray-900/50 backdrop-blur-sm border-gray-200 dark:border-gray-800">
        <CardHeader>
          <CardTitle>Research Access</CardTitle>
          <CardDescription>Connect your wallet to access research content</CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col items-center justify-center py-10">
          <div className="relative w-24 h-24 mb-6">
            <Lock className="w-24 h-24 text-gray-300 dark:text-gray-700" />
            <div className="absolute inset-0 bg-purple-500 rounded-full blur-xl opacity-20"></div>
          </div>
          <Button
            className="bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700"
            onClick={onConnect}
          >
            Connect Wallet
          </Button>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      <Card className="bg-white dark:bg-gray-900/50 backdrop-blur-sm border-gray-200 dark:border-gray-800 overflow-hidden relative">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-100/30 to-pink-100/30 dark:from-purple-900/10 dark:to-pink-900/10 rounded-lg"></div>
        <CardHeader className="relative z-10">
          <div className="flex justify-between items-start">
            <div>
              <CardTitle>Research Access</CardTitle>
              <CardDescription>Access exclusive research content with your NFTs</CardDescription>
            </div>
            <div className="flex space-x-2">
              {hasBasicAccess && (
                <Badge
                  variant="outline"
                  className="border-green-300 dark:border-green-600 text-green-600 dark:text-green-400 bg-green-100/50 dark:bg-green-900/20"
                >
                  Basic Access
                </Badge>
              )}
              {hasPremiumAccess && (
                <Badge
                  variant="outline"
                  className="border-purple-300 dark:border-purple-600 text-purple-600 dark:text-purple-400 bg-purple-100/50 dark:bg-purple-900/20"
                >
                  Premium Access
                </Badge>
              )}
              {hasExclusiveAccess && (
                <Badge
                  variant="outline"
                  className="border-pink-300 dark:border-pink-600 text-pink-600 dark:text-pink-400 bg-pink-100/50 dark:bg-pink-900/20"
                >
                  Exclusive Access
                </Badge>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent className="relative z-10">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid grid-cols-3 mb-6">
              <TabsTrigger value="available">Available</TabsTrigger>
              <TabsTrigger value="premium">Premium</TabsTrigger>
              <TabsTrigger value="exclusive">Exclusive</TabsTrigger>
            </TabsList>

            <TabsContent value="available">
              <div className="space-y-4">
                {hasBasicAccess ? (
                  <>
                    <ResearchItem
                      title="Market Analysis Q2 2023"
                      description="Comprehensive analysis of the crypto market trends"
                      date="June 15, 2023"
                      type="Report"
                      hasAccess={true}
                    />
                    <ResearchItem
                      title="Blockchain Technology Overview"
                      description="Introduction to blockchain technology and its applications"
                      date="May 10, 2023"
                      type="Guide"
                      hasAccess={true}
                    />
                    <ResearchItem
                      title="DeFi Ecosystem Explained"
                      description="Deep dive into the decentralized finance ecosystem"
                      date="April 22, 2023"
                      type="Report"
                      hasAccess={true}
                    />
                  </>
                ) : (
                  <div className="text-center py-10">
                    <Lock className="h-12 w-12 mx-auto text-gray-300 dark:text-gray-700 mb-4" />
                    <p className="text-gray-500 dark:text-gray-400">No access to research content</p>
                    <p className="text-sm text-gray-500 dark:text-gray-500 mt-1">
                      Stake your tokens to earn access NFTs
                    </p>
                    <Button
                      variant="outline"
                      className="mt-4 border-purple-300 dark:border-purple-700 text-purple-600 dark:text-purple-400 hover:bg-purple-100/50 dark:hover:bg-purple-900/20"
                      onClick={() => (window.location.href = "#staking")}
                    >
                      Go to Staking
                    </Button>
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="premium">
              <div className="space-y-4">
                {hasPremiumAccess ? (
                  <>
                    <ResearchItem
                      title="Tokenomics Deep Dive"
                      description="Advanced analysis of token economics and design patterns"
                      date="July 5, 2023"
                      type="Report"
                      hasAccess={true}
                    />
                    <ResearchItem
                      title="NFT Market Trends"
                      description="Comprehensive analysis of the NFT market and future projections"
                      date="June 28, 2023"
                      type="Analysis"
                      hasAccess={true}
                    />
                    <ResearchItem
                      title="Layer 2 Scaling Solutions"
                      description="Technical comparison of Layer 2 scaling solutions"
                      date="June 10, 2023"
                      type="Technical"
                      hasAccess={true}
                    />
                  </>
                ) : (
                  <div className="text-center py-10">
                    <Lock className="h-12 w-12 mx-auto text-gray-300 dark:text-gray-700 mb-4" />
                    <p className="text-gray-500 dark:text-gray-400">Premium access required</p>
                    <p className="text-sm text-gray-500 dark:text-gray-500 mt-1">
                      Stake 500+ tokens for 60 days to earn Premium Access NFT
                    </p>
                    <Button
                      variant="outline"
                      className="mt-4 border-purple-300 dark:border-purple-700 text-purple-600 dark:text-purple-400 hover:bg-purple-100/50 dark:hover:bg-purple-900/20"
                      onClick={() => (window.location.href = "#staking")}
                    >
                      Go to Staking
                    </Button>
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="exclusive">
              <div className="space-y-4">
                {hasExclusiveAccess ? (
                  <>
                    <ResearchItem
                      title="Institutional Crypto Adoption"
                      description="Exclusive research on institutional adoption of cryptocurrencies"
                      date="July 20, 2023"
                      type="Exclusive"
                      hasAccess={true}
                    />
                    <ResearchItem
                      title="Regulatory Landscape 2023"
                      description="Comprehensive analysis of global crypto regulations"
                      date="July 15, 2023"
                      type="Exclusive"
                      hasAccess={true}
                    />
                    <ResearchItem
                      title="Future of DeFi: 2024-2025"
                      description="Predictions and analysis for the future of decentralized finance"
                      date="July 5, 2023"
                      type="Forecast"
                      hasAccess={true}
                    />
                  </>
                ) : (
                  <div className="text-center py-10">
                    <Lock className="h-12 w-12 mx-auto text-gray-300 dark:text-gray-700 mb-4" />
                    <p className="text-gray-500 dark:text-gray-400">Exclusive access required</p>
                    <p className="text-sm text-gray-500 dark:text-gray-500 mt-1">
                      Stake 1000+ tokens for 90 days to earn Exclusive Access NFT
                    </p>
                    <Button
                      variant="outline"
                      className="mt-4 border-purple-300 dark:border-purple-700 text-purple-600 dark:text-purple-400 hover:bg-purple-100/50 dark:hover:bg-purple-900/20"
                      onClick={() => (window.location.href = "#staking")}
                    >
                      Go to Staking
                    </Button>
                  </div>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}

interface ResearchItemProps {
  title: string
  description: string
  date: string
  type: string
  hasAccess: boolean
}

function ResearchItem({ title, description, date, type, hasAccess }: ResearchItemProps) {
  return (
    <div className="p-4 bg-gray-100/80 dark:bg-gray-800/50 rounded-lg flex items-start">
      <div className="p-3 bg-gray-200 dark:bg-gray-800 rounded-full mr-4">
        <FileText className="h-5 w-5 text-purple-600 dark:text-purple-500" />
      </div>
      <div className="flex-1">
        <div className="flex justify-between items-start">
          <h4 className="font-medium">{title}</h4>
          <Badge variant="outline" className="ml-2 text-xs">
            {type}
          </Badge>
        </div>
        <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">{description}</p>
        <div className="flex justify-between items-center mt-2">
          <span className="text-xs text-gray-500">{date}</span>
          <Button
            variant="ghost"
            size="sm"
            className="h-8 text-purple-600 dark:text-purple-400 hover:text-purple-700 dark:hover:text-purple-300"
          >
            <ExternalLink className="h-3 w-3 mr-1" />
            View
          </Button>
        </div>
      </div>
    </div>
  )
}
