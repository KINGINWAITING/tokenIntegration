"use client"

import { useState, useEffect } from "react"
import { V0ComponentWrapper } from "@/components/v0-component-wrapper"
import { useWallet } from "@/hooks/use-wallet"
import { useContractData } from "@/hooks/use-contract"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { WalletSection } from "./components/wallet-section"
import { OnrampSection } from "./components/onramp-section"
import { StakingSection } from "./components/staking-section"
import { GovernanceSection } from "./components/governance-section"
import { ResearchAccessSection } from "./components/research-access-section"
import { DashboardHeader } from "./components/dashboard-header"
import { DashboardStats } from "./components/dashboard-stats"
import { Canvas } from "@react-three/fiber"
import { Environment, OrbitControls } from "@react-three/drei"
import { TokenModel } from "./components/token-model"
import { ThemeProvider } from "@/components/theme-provider"

export default function DashboardPage() {
  const { address, isConnected, connectWallet } = useWallet()
  const { data: tokenData, isLoading: tokenLoading } = useContractData("token")
  const { data: nftData, isLoading: nftLoading } = useContractData("nft")
  const { data: stakingData, isLoading: stakingLoading } = useContractData("staking")

  const [activeTab, setActiveTab] = useState("wallet")
  const [showWelcome, setShowWelcome] = useState(false)

  useEffect(() => {
    // Check if this is a new user - safely check for localStorage
    if (typeof window !== "undefined") {
      const isNewUser = !localStorage.getItem("walletCreated")
      setShowWelcome(isNewUser && !isConnected)

      if (isConnected && isNewUser) {
        localStorage.setItem("walletCreated", "true")
      }
    }
  }, [isConnected])

  return (
    <ThemeProvider attribute="class" defaultTheme="light" enableSystem>
      <V0ComponentWrapper
        title="MOONSET Dashboard"
        description="Manage your crypto assets, stake tokens, and participate in governance"
        requiresWallet={false}
      >
        <div className="relative min-h-screen bg-white dark:bg-gradient-to-b dark:from-gray-900 dark:to-gray-950 text-gray-900 dark:text-white">
          {/* 3D Background Element */}
          <div className="absolute inset-0 opacity-10 dark:opacity-20 pointer-events-none">
            <Canvas>
              <ambientLight intensity={0.5} />
              <OrbitControls enableZoom={false} enablePan={false} autoRotate />
              <TokenModel position={[0, 0, 0]} scale={3} />
              <Environment preset="sunset" />
            </Canvas>
          </div>

          <div className="container mx-auto px-4 py-8 relative z-10">
            <DashboardHeader address={address} isConnected={isConnected} onConnect={connectWallet} />

            {showWelcome ? (
              <WelcomeScreen
                onComplete={() => {
                  connectWallet()
                  setShowWelcome(false)
                }}
              />
            ) : (
              <>
                <DashboardStats
                  tokenData={tokenData}
                  nftData={nftData}
                  stakingData={stakingData}
                  isLoading={tokenLoading || nftLoading || stakingLoading}
                />

                <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-8">
                  <TabsList className="grid grid-cols-5 mb-8">
                    <TabsTrigger value="wallet">Wallet</TabsTrigger>
                    <TabsTrigger value="onramp">Buy Tokens</TabsTrigger>
                    <TabsTrigger value="staking">Staking</TabsTrigger>
                    <TabsTrigger value="research">Research Access</TabsTrigger>
                    <TabsTrigger value="governance">Governance</TabsTrigger>
                  </TabsList>

                  <TabsContent value="wallet" className="mt-4">
                    <WalletSection
                      address={address}
                      isConnected={isConnected}
                      tokenData={tokenData}
                      nftData={nftData}
                      isLoading={tokenLoading || nftLoading}
                      onConnect={connectWallet}
                    />
                  </TabsContent>

                  <TabsContent value="onramp" className="mt-4">
                    <OnrampSection
                      address={address}
                      isConnected={isConnected}
                      tokenData={tokenData}
                      isLoading={tokenLoading}
                      onConnect={connectWallet}
                    />
                  </TabsContent>

                  <TabsContent value="staking" className="mt-4">
                    <StakingSection
                      address={address}
                      isConnected={isConnected}
                      tokenData={tokenData}
                      stakingData={stakingData}
                      isLoading={tokenLoading || stakingLoading}
                      onConnect={connectWallet}
                    />
                  </TabsContent>

                  <TabsContent value="research" className="mt-4">
                    <ResearchAccessSection
                      address={address}
                      isConnected={isConnected}
                      nftData={nftData}
                      isLoading={nftLoading}
                      onConnect={connectWallet}
                    />
                  </TabsContent>

                  <TabsContent value="governance" className="mt-4">
                    <GovernanceSection
                      address={address}
                      isConnected={isConnected}
                      tokenData={tokenData}
                      isLoading={tokenLoading}
                      onConnect={connectWallet}
                    />
                  </TabsContent>
                </Tabs>
              </>
            )}
          </div>
        </div>
      </V0ComponentWrapper>
    </ThemeProvider>
  )
}

function WelcomeScreen({ onComplete }: { onComplete: () => void }) {
  return (
    <div className="flex flex-col items-center justify-center min-h-[60vh] text-center">
      <div className="relative w-40 h-40 mb-8">
        <Canvas>
          <ambientLight intensity={0.8} />
          <spotLight position={[10, 10, 10]} angle={0.15} penumbra={1} />
          <TokenModel position={[0, 0, 0]} scale={5} />
          <OrbitControls enableZoom={false} autoRotate />
          <Environment preset="sunset" />
        </Canvas>
      </div>

      <h1 className="text-4xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-purple-500 to-pink-600">
        Welcome to MOONSET
      </h1>
      <p className="text-xl text-gray-600 dark:text-gray-300 mb-8 max-w-2xl">
        We're creating your embedded wallet automatically to get you started with crypto in seconds.
      </p>
      <button
        onClick={onComplete}
        className="px-8 py-3 bg-gradient-to-r from-purple-500 to-pink-600 rounded-lg font-medium text-white shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105"
      >
        Get Started
      </button>
    </div>
  )
}
